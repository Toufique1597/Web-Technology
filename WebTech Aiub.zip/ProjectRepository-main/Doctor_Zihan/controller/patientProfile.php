<?php

require_once 'model.php';

$patient = viewPatientProfile($_GET['p_id']);

?>