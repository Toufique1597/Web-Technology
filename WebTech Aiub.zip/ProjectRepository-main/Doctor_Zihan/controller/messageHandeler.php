<?php

require_once 'model.php';

$patients = showMessageRequests($_SESSION['d_id']);

?>